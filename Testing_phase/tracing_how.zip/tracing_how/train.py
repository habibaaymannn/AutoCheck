import numpy as np

# Simple linear regression with gradient descent
np.random.seed(42)
X = np.random.randn(100, 1)
y = 3 * X.squeeze() + 2 + np.random.randn(100) * 0.1

# parameters
w = 0.0
b = 0.0
lr = 0.01
epochs = 100000

for epoch in range(epochs):
    # forward pass
    y_pred = w * X.squeeze() + b
    loss = np.mean((y_pred - y) ** 2)

    # backward pass
    dw = np.mean(2 * (y_pred - y) * X.squeeze())
    db = np.mean(2 * (y_pred - y))

    # update
    w -= lr * dw
    b -= lr * db

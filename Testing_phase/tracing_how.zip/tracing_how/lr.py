import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import time

df = pd.read_csv('international-airline-passengers.csv', engine='python', skipfooter=3)
df.columns = ['month', 'num_passengers']

series = df.num_passengers.to_numpy()
N = len(series)

# repeat the series many times to create a much larger dataset
series = np.tile(series, 50)
N = len(series)

REPEATS = 100  # outer repetition loop to simulate long training

for step in range(REPEATS):
    print(f"\n=== Repeat {step+1}/{REPEATS} ===")

    for D in (2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16, 18, 20):
        n = N - D
        X = np.zeros((n, D))
        for d in range(D):
            X[:, d] = series[d:d+n]
        Y = series[D:D+n]

        Xtrain = X[:n//2]
        Ytrain = Y[:n//2]
        Xtest  = X[n//2:]
        Ytest  = Y[n//2:]

        model = LinearRegression()
        model.fit(Xtrain, Ytrain)

        train_score = model.score(Xtrain, Ytrain)
        test_score  = model.score(Xtest,  Ytest)
        print(f"  D={D:2d} | series length: {n} | train: {train_score:.4f} | test: {test_score:.4f}")

        # simulate heavier computation per iteration
        _ = np.linalg.lstsq(Xtrain, Ytrain, rcond=None)

        train_series = np.empty(n)
        train_series[:n//2] = model.predict(Xtrain)
        train_series[n//2:] = np.nan

        test_series = np.empty(n)
        test_series[:n//2] = np.nan
        test_series[n//2:] = model.predict(Xtest)

        # small sleep to make time-based checkpointing visible
        time.sleep(0.5)
import sys
import os
import json
import ctypes
import numpy as np
import ast

import time

MAX_RUNTIME = 10  # seconds


class ResumeTransformer(ast.NodeTransformer):
    """
    Rewrites the first for-loop whose variable is 'epoch' or 'step':
        for epoch in range(epochs)
    becomes:
        for epoch in range(__resume_start__, epochs)
    so the loop skips already-trained iterations on resume.
    """

    RESUME_VARS = {"epoch", "step"}

    def __init__(self, start_var="__resume_start__"):
        self.start_var = start_var
        self.patched   = set()   # track which vars we already patched

    def visit_For(self, node):
        self.generic_visit(node)  # handle nested loops first

        if not isinstance(node.target, ast.Name):
            return node

        var_name = node.target.id
        if var_name not in self.RESUME_VARS:
            return node
        if var_name in self.patched:
            return node

        # only patch range() calls
        if not (isinstance(node.iter, ast.Call) and
                isinstance(node.iter.func, ast.Name) and
                node.iter.func.id == "range"):
            return node

        args = node.iter.args

        # build: __resume_start__   (an ast.Name node)
        resume_node = ast.Name(id=self.start_var, ctx=ast.Load())

        if len(args) == 1:
            # range(N)  →  range(__resume_start__, N)
            node.iter.args = [resume_node, args[0]]
        elif len(args) >= 2:
            # range(start, N)  →  range(__resume_start__, N)
            node.iter.args = [resume_node] + list(args[1:])

        self.patched.add(var_name)
        print(f"[AST] patched loop variable '{var_name}' to start from {self.start_var}")
        return node


def transform_source(source, start_value, script_path):
    """Parse source, patch the epoch/step loop, return compiled code."""
    tree        = ast.parse(source)
    transformer = ResumeTransformer()
    new_tree    = transformer.visit(tree)
    ast.fix_missing_locations(new_tree)
    return compile(new_tree, script_path, "exec")


# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
CHECKPOINT_FILE  = "checkpoint.json"
CHECKPOINT_EVERY = 5          # save every N epochs (configurable)
TARGET_SCRIPT    = ""

# only these two variables are tracked by the tracer
TRACKED_VARS = {"epoch", "step"}
current_values = {}           # latest seen values, read by the runner


# ─────────────────────────────────────────────
# VARIABLE INJECTION
# ─────────────────────────────────────────────
def set_var(frame, name, value):
    frame.f_locals[name] = value
    ctypes.pythonapi.PyFrame_LocalsToFast(
        ctypes.py_object(frame), ctypes.c_int(0)
    )


# ─────────────────────────────────────────────
# FRAMEWORK DETECTION
# ─────────────────────────────────────────────
def detect_framework(locals_vars):
    for value in locals_vars.values():
        module = type(value).__module__
        if "torch" in module:
            return "pytorch"
        if "keras" in module or "tensorflow" in module:
            return "keras"
        if "sklearn" in module:
            return "sklearn"
    return "numpy"


# ─────────────────────────────────────────────
# SAVE CHECKPOINT
# ─────────────────────────────────────────────
def save_checkpoint(locals_vars):
    framework = detect_framework(locals_vars)

    # use step if no epoch exists
    progress_key = "epoch" if "epoch" in locals_vars else "step"
    progress_val = int(locals_vars.get(progress_key, 0))

    meta = {
        "framework": framework,
        "epoch": progress_val,  # always store as epoch for simplicity
        "_progress_key": progress_key,  # remember which variable it was
        "loss": float(locals_vars.get("loss", 0.0)),
    }

    if framework == "pytorch":
        import torch
        model     = next((v for v in locals_vars.values() if isinstance(v, torch.nn.Module)), None)
        optimizer = next((v for v in locals_vars.values() if isinstance(v, torch.optim.Optimizer)), None)
        torch.save({
            **meta,
            "model_state_dict":     model.state_dict()     if model     else None,
            "optimizer_state_dict": optimizer.state_dict() if optimizer else None,
        }, "checkpoint.pth")
        with open(CHECKPOINT_FILE, "w") as f:
            json.dump(meta, f, indent=2)

    elif framework == "keras":
        import tensorflow as tf
        model = next((v for v in locals_vars.values() if isinstance(v, tf.keras.Model)), None)
        if model:
            model.save("checkpoint.keras")
        with open(CHECKPOINT_FILE, "w") as f:
            json.dump(meta, f, indent=2)

    elif framework == "sklearn":
        import joblib
        model = next((v for v in locals_vars.values()
                      if hasattr(v, "fit") and hasattr(v, "predict")), None)
        if model:
            joblib.dump(model, "checkpoint.pkl")
        with open(CHECKPOINT_FILE, "w") as f:
            json.dump(meta, f, indent=2)

    else:  # numpy / plain python fallback
        numpy_vars  = {k: v.tolist() for k, v in locals_vars.items()
                       if isinstance(v, np.ndarray)}
        scalar_vars = {k: v for k, v in locals_vars.items()
                       if isinstance(v, (int, float, str, bool))}
        with open(CHECKPOINT_FILE, "w") as f:
            json.dump({**meta, **scalar_vars, "arrays": numpy_vars}, f, indent=2)

    print(f"[CHECKPOINT] saved ({framework}) at epoch={meta['epoch']}  loss={meta['loss']:.4f}")


# ─────────────────────────────────────────────
# LOAD CHECKPOINT
# ─────────────────────────────────────────────
def load_checkpoint():
    if not os.path.exists(CHECKPOINT_FILE):
        return None
    with open(CHECKPOINT_FILE) as f:
        meta = json.load(f)

    progress_key = meta.get("_progress_key", "epoch")
    start = meta.get("epoch", 0) + 1
    meta[progress_key] = start - 1  # inject under correct name
    framework = meta.get("framework", "numpy")
    restored  = dict(meta)

    if framework == "pytorch" and os.path.exists("checkpoint.pth"):
        import torch
        restored["__pth__"] = torch.load("checkpoint.pth")

    elif framework == "keras" and os.path.exists("checkpoint.keras"):
        import tensorflow as tf
        restored["__keras_model__"] = tf.keras.models.load_model("checkpoint.keras")

    elif framework == "sklearn" and os.path.exists("checkpoint.pkl"):
        import joblib
        restored["__sklearn_model__"] = joblib.load("checkpoint.pkl")

    else:  # numpy fallback
        arrays = meta.pop("arrays", {})
        for k, v in arrays.items():
            restored[k] = np.array(v)

    print(f"[RESTORE] loaded checkpoint — epoch={meta['epoch']}  loss={meta['loss']:.4f}")
    return restored


# ─────────────────────────────────────────────
# TRACER — only watches epoch / step
# ─────────────────────────────────────────────
def trace_func(frame, event, arg):
    if event != "line":
        return trace_func

    if os.path.abspath(frame.f_code.co_filename) != TARGET_SCRIPT:
        return trace_func

    locals_vars = frame.f_locals

    # update current_values whenever epoch or step changes
    for name in TRACKED_VARS:
        if name in locals_vars:
            value = locals_vars[name]
            if current_values.get(name) != value:
                current_values[name] = value
                print(f"[PROGRESS] {name} = {value}")

                # tell the runner to decide whether to checkpoint
                _maybe_checkpoint(locals_vars)

    return trace_func

last_ckpt_t = 0
def _maybe_checkpoint(locals_vars):
    global last_ckpt_t
    elapsed = time.time() - START_TIME

    """Called by tracer — runner logic decides when to save."""
    epoch = current_values.get("epoch")
    step  = current_values.get("step")
    now = time.time()

    if elapsed > MAX_RUNTIME and elapsed > 2:
        print("[TIME LIMIT] Saving checkpoint before exit...")
        save_checkpoint(locals_vars)
        sys.exit(0)

    # checkpoint every N epochs
    if epoch is not None and epoch % CHECKPOINT_EVERY == 0:
        print("[TIME LIMIT] Saving (epoch)...")
        save_checkpoint(locals_vars)

    # or every N steps if no epoch variable exists
    elif epoch is None and step is not None and step % CHECKPOINT_EVERY == 0:
        print("[TIME LIMIT] Saving checkpoint (step)...")
        save_checkpoint(locals_vars)

    elif now - last_ckpt_t >= CHECKPOINT_EVERY:
        print("[TIME LIMIT] Saving checkpoint (time))...")
        save_checkpoint(locals_vars)
        last_checkpoint_time = now


# ─────────────────────────────────────────────
# INJECT RESTORED VARIABLES INTO FRAME
# ─────────────────────────────────────────────
def make_restore_tracer(checkpoint):
    def restore_tracer(frame, event, arg):
        if event != "call":
            return restore_tracer
        if os.path.abspath(frame.f_code.co_filename) != TARGET_SCRIPT:
            return restore_tracer

        # inject scalars and arrays
        for name, value in checkpoint.items():
            if name.startswith("__") or name in ("framework",):
                continue
            try:
                set_var(frame, name, value)
            except Exception:
                pass

        # pytorch: restore model + optimizer weights into live objects
        if "__pth__" in checkpoint:
            pth = checkpoint["__pth__"]
            for value in frame.f_locals.values():
                try:
                    import torch
                    if isinstance(value, torch.nn.Module) and pth.get("model_state_dict"):
                        value.load_state_dict(pth["model_state_dict"])
                    if isinstance(value, torch.optim.Optimizer) and pth.get("optimizer_state_dict"):
                        value.load_state_dict(pth["optimizer_state_dict"])
                except Exception:
                    pass

        print("[RESTORE] variables injected into frame")
        return trace_func  # hand off to normal tracer

    return restore_tracer


# ─────────────────────────────────────────────
# MAIN RUNNER
# ─────────────────────────────────────────────
def run_user_code(script, resume=False, checkpoint_every=5):
    global TARGET_SCRIPT, CHECKPOINT_EVERY, START_TIME
    TARGET_SCRIPT    = os.path.abspath(script)
    CHECKPOINT_EVERY = checkpoint_every
    START_TIME = time.time()

    with open(script) as f:
        source = f.read()

    checkpoint = load_checkpoint() if resume else None

    globs = {}
    if checkpoint:
        start_epoch = checkpoint.get("epoch", 0) + 1  # resume AFTER last saved epoch
        globs["__resume_start__"] = start_epoch
        for name, value in checkpoint.items():
            if not name.startswith("__") and name not in ("framework",):
                globs[name] = value
        code = transform_source(source, start_epoch, TARGET_SCRIPT)
        print(f"[RESUME] starting from epoch={start_epoch}")

    else:
        globs["__resume_start__"] = 0
        code = compile(source, script, "exec")

    sys.settrace(trace_func)
    exec(code, globs)
    sys.settrace(None)


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="AutoCheck — ML training checkpointer")
    parser.add_argument("--max-time", "-t", type=int,default=None,help="maximum runtime in seconds")
    parser.add_argument("script",         help="training script to run")
    parser.add_argument("--resume",           "-r", action="store_true", help="resume from last checkpoint")
    parser.add_argument("--checkpoint-every", "-n", type=int, default=5, help="save every N epochs (default: 5)")
    args = parser.parse_args()

    run_user_code(args.script, resume=args.resume, checkpoint_every=args.checkpoint_every)

